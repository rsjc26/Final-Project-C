//Reversing the bits using unsigned Integer

#include <stdio.h>
#include <stdlib.h>

#define charbits  2  // size of character
#define intbits  ( sizeof(int) * charbits)

void bin(unsigned n)
{
	short int pos;
	
	for (pos = (intbits -1) ; pos >= 0 ; pos--)
	{
	  (n & (1 << pos))? printf("1"): printf("0");	
	}
		
		

}


unsigned int ReverseTheBits(unsigned int num)
{
    unsigned int loop = 0;
    unsigned int tmp = 0;         
    int numloop = (intbits - 1);
	     
  
    for(; loop < numloop; loop++)
    {
	      
       tmp |= num & 1; 
       num >>= 1;  
       tmp <<= 1;  
       
    }
    
    return tmp;
}
 
int main()
{
    unsigned int data = 0;
    unsigned int Ret = 0;
    
    printf("Enter the number : ");
    scanf("%u",&data);
    
    printf("\n\nOriginal Data ");
    bin(data);
    
    
    Ret = ReverseTheBits(data);

    printf("\n\nReverse Data ");
    bin(Ret);
    
return 0;
}
