// Parent and Child String

#include<stdio.h>
#include<string.h>
int n;
char name[20];

struct celn{
char child[20];
char father[20];
}c[10];

int count=0;
void grandchild(char name[])
    {
    int j;
    for(j=0;j<n;j++)
        {
        if(strcmp(name,c[j].father)==0)
            {
            count++;
            grandchild(c[j].child);
            }
        }
    }

void main()
{
int i;
printf("\nEnter the number of inputs: ");
scanf("%d",&n);
for(i=0;i<n;i++)
    {
    scanf("%s",c[i].child);
    scanf("%s",c[i].father);
    }
printf("\nInput ");
scanf("%s",name);
for(i=0;i<n;i++)
    {
    if(strcmp(c[i].father,name)==0)
        grandchild(c[i].child);
    }
printf("\nOutput %s=%d",name,count);
}
